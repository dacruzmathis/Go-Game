package test;

import gui.MainGUI;

public class GoGUI {
	
	public static void main(String[] args) {
		 	
		MainGUI goGui = new MainGUI("Menu");
	}

}
