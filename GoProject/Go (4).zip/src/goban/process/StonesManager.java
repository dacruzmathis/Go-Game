/**
 * 
 */
package goban.process;
import goban.stones.*;

import java.util.ArrayList;
import java.util.List;

import goban.map.Goban;



/**
 * @author afatc
 *
 */
public class StonesManager {
	private Goban goban;
	
	private List<Stones> StonesIntersection = new ArrayList<Stones>();

	
	public StonesManager(Goban goban) {
		this.goban = goban;
	}
	
	public void putStones (Stones stones) {	
		StonesIntersection.add(stones);
	}

	public List<Stones> getStonesIntersection() {
		return StonesIntersection;
	}

	public void setStonesIntersection(List<Stones> stonesIntersection) {
		StonesIntersection = stonesIntersection;
	}
	
}

	
