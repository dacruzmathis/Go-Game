/**
 * 
 */
package goban.stones;

import goban.map.Intersection;

/**
 * @author afatc
 *
 */
public class MegaStone extends Stones{
	
	public MegaStone(Intersection position) {
		super(position);
	}
}
