/**
 * 
 */
package gui;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JFrame;

import config.GobanConfiguration;
import goban.map.Goban;
import goban.map.Intersection;
import goban.process.GameBuilder;
import goban.process.StonesManager;
import goban.stones.BlackStone;
import goban.stones.RedStone;
import goban.stones.Stones;
import goban.stones.WhiteStone;


/**
 * @author afatc
 *
 */
public class MainGUI extends JFrame{
	
	private static final long serialVersionUID = 1L;
	
	private Goban goban;
	 
	private StonesManager manager;
	
	private GameDisplay dashboard;
	
	private final static Dimension preferredSize = new Dimension(GobanConfiguration.WINDOW_WIDTH, GobanConfiguration.WINDOW_HEIGHT);
	
	public MainGUI(String title) {
		super(title);
		init();
	}
	
	private void init() {
		
		Container contentPane = getContentPane();
		contentPane.setLayout(new BorderLayout());

		goban = GameBuilder.buildGoban();
		manager = GameBuilder.InitStones(goban);
		dashboard = new GameDisplay(goban, manager);
		
		MouseControls mouseControls = new MouseControls();
		dashboard.addMouseListener(mouseControls); 
		
		dashboard.setPreferredSize(preferredSize);
		contentPane.add(dashboard,BorderLayout.CENTER);
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		pack();
		setVisible(true);
		setPreferredSize(preferredSize);
		setResizable(false);
	}
	
	private class MouseControls implements MouseListener {
		/*This is for alternate colors of the stones when we click with the mouse*/
		public void mouseClicked(MouseEvent arg0) {
			int x = arg0.getX()+(GobanConfiguration.BLOCK_SIZE/2);
			int y = arg0.getY()+(GobanConfiguration.BLOCK_SIZE/2);
			if(GobanConfiguration.TURN%3==0) {
				Intersection stonePosition = dashboard.getStonePosition(x,y);
				Stones blackstones = new BlackStone(stonePosition); 
				manager.putStones(blackstones);
			}
			else if(GobanConfiguration.TURN%3==1) {
				Intersection stonePosition = dashboard.getStonePosition(x,y);
				Stones whitestones = new WhiteStone(stonePosition);
				manager.putStones(whitestones);
			}
			else {
				Intersection stonePosition = dashboard.getStonePosition(x,y);
				Stones redstones = new RedStone(stonePosition);
				manager.putStones(redstones);
			}
			GobanConfiguration.TURN++;
			dashboard.repaint();
		}
		
		@Override
		public void mouseEntered(MouseEvent arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseExited(MouseEvent arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mousePressed(MouseEvent arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseReleased(MouseEvent arg0) {
			// TODO Auto-generated method stub
			
		}
	}
}
